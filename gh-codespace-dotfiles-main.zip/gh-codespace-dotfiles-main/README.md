## Dotfiles repo

A fairly basic dotfiles repo.  Focused on GitHub Codespaces.

This does include a `bootstrap.sh` script because I want to clone in other repos (e.g. `shea-parkes/neovim-config`).
